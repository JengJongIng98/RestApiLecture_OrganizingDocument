using System.ComponentModel.DataAnnotations;

namespace GuestbookEFCore_ListUI.Models
{
    public class GuestbookEntry
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(50)]
        public string UserId { get; set; } = string.Empty;

        [Required, StringLength(50)]
        public string Name { get; set; } = string.Empty;

        [Required, StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required]
        public string Content { get; set; } = string.Empty;

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}