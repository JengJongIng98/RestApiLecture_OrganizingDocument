using GuestbookEFCore_ListUI.Models;
using Microsoft.EntityFrameworkCore;

namespace GuestbookEFCore_ListUI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<GuestbookEntry> GuestbookEntries { get; set; } = null!;
    }
}