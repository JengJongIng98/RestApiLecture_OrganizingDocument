using GuestbookEFCore_ListUI.Data;
using GuestbookEFCore_ListUI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GuestbookEFCore_ListUI.Controllers
{
    public class GuestbookController : Controller
    {
        private readonly ApplicationDbContext _context;
        public GuestbookController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string? q)
        {
            var query = _context.GuestbookEntries.AsQueryable();
            if (!string.IsNullOrWhiteSpace(q))
            {
                query = query.Where(x =>
                    x.UserId.Contains(q) || x.Name.Contains(q) ||
                    x.Title.Contains(q) || x.Content.Contains(q));
            }
            var items = await query.OrderByDescending(x => x.Id).ToListAsync();
            return View(items);
        }

        public async Task<IActionResult> Details(int id)
        {
            var item = await _context.GuestbookEntries.FindAsync(id);
            if (item == null) return NotFound();
            return View(item);
        }

        public IActionResult Create() => View(new GuestbookEntry());

        [HttpPost]
        public async Task<IActionResult> Create(GuestbookEntry entry)
        {
            if (!ModelState.IsValid) return View(entry);
            entry.CreatedAt = DateTime.Now;
            _context.GuestbookEntries.Add(entry);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id)
        {
            var item = await _context.GuestbookEntries.FindAsync(id);
            if (item == null) return NotFound();
            return View(item);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(GuestbookEntry entry)
        {
            if (!ModelState.IsValid) return View(entry);
            _context.GuestbookEntries.Update(entry);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int id)
        {
            var item = await _context.GuestbookEntries.FindAsync(id);
            if (item == null) return NotFound();
            return View(item);
        }

        [HttpPost, ActionName("DeleteConfirmed")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var item = await _context.GuestbookEntries.FindAsync(id);
            if (item == null) return NotFound();
            _context.GuestbookEntries.Remove(item);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}